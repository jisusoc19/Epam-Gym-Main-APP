
INSERT INTO usergym (first_Name, last_Name, username, password, is_Active) VALUES ('Nombre', 'Apellido', 'hola', 'hola', true);
INSERT INTO trainer (first_Name, last_Name, pasword, username, is_Active) VALUES ('Nombre', 'Apellido', 'Contraseña', 'NombreUsuario', true);